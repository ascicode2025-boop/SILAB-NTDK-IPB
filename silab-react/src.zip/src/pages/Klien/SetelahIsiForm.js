function SetelahIsiForm() {
  React.useEffect(() => {
    document.title = "SILAB-NTDK - Setelah Isi Form";
  }, []);

  return <div>Setelah Isi Form</div>;
}
